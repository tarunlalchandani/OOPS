#include<bits/stdc++.h>
using namespace std;

class Employee {
protected:
	string emp_id;
	int emp_sallary;
	float emp_da;
public:
	void getData() {
		cout<<"Enter "<<"id : "; cin>>emp_id;
		cout<<"Enter "<<"sallary : "; cin>>emp_sallary;
		emp_da = emp_sallary/5;
	}
	Employee() {
		emp_id = "";
		emp_sallary = 0;
		emp_da = emp_sallary/5;
	}
	Employee(string id, int sallary) {
		emp_id = id;
		emp_sallary = sallary;
		emp_da = emp_sallary/5;
	}
	
	void putData() {
		cout<<"id: "<<emp_id<<" | sallary: "<<emp_sallary<<" | DA: "<<emp_da<<" |"<<endl;
	}
	
};

int main() {
	Employee e[5];
	
	for (int i=0; i<5; i++) {
		cout<<"Employee: "<<i+1<<endl;
		e[i].getData();
	}
	cout<<endl;
	for (int i=0; i<5; i++) {
		e[i].putData();
	}

	return 0;
}

