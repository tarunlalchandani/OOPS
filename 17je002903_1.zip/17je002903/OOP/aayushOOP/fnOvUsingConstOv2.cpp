#include<bits/stdc++.h>
using namespace std;
//function overloading using constructor overloading

bool isMoreThanOnce(string &s, char c) {
	int occurance = 0;
	for(int i=0; i<s.length(); i++) {
		if (s[i] == c ) {
			occurance++;
			s[i]='-';
		}
	}

	if(occurance > 1) return true;
	return false;
}

class St {

public:
	St(string s) {
		int i=0, n=s.length();
		int k; cout<<"Enter K for K-Shift\n"; cin>>k;
		
		for (i; i<n; i++) {
			cout<<s[(i+k)%n];
		}
	}


	St (string s1, string s2) {
		if(s1.length() > s2.length()) {
			cout<<s1<<" is greatest\n";
		}
		else if ( s1.length() < s2.length() ) cout<<s2<<" is greatest\n";
		else cout<<"Equal\n";
	}

	St (string s1, string s2, string s3) {
		string s = s1+s2+s3;
		
		for(int i=0 ; i<s.length(); i++) {
			 if(s[i] != '-') if(isMoreThanOnce(s, s[i])) {
				cout<<s[i];
			}
		}
	}
};






int main() {
//	St("abcdefghi");
	St("abc", "abcd");
//	St("abc", "abcde", "ddcef");
	
	
	return 0;
}

