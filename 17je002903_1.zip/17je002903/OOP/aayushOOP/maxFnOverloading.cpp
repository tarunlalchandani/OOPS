#include<bits/stdc++.h>
using namespace std;
//overload function max
class A {
	
public:
	int Max(int a, int b){
		if(a>b) return a;
		return b;
	}
	
	int Max(int a, int b, int c){
		int res = a>b ? a : b;
		res = res>c ? res : c;
		return res;
	}
	
	float Max(double a, double b){
		if(a>b) return a;
		return b;
	}
	
	float Max(double a, double b, double c){
		double res = a>b ? a : b;
		res = res>c ? res : c;
		return res;
	}

};


int main() {
	A a;
	cout<<a.Max(1,2)<<'\n';
	cout<<a.Max(1,3,2)<<'\n';
	cout<<a.Max(1.5, 2.63)<<'\n';
	cout<<a.Max(83.5, 125.1, 555.1)<<'\n';
	
	
	return 0;
}

