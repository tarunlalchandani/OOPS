#include<bits/stdc++.h>
using namespace std;



struct student{
	int rno;
	string name;
	float marks;
};
int main()
{int a;
	student obj[4];
	for(int i=1;i<=3;i++)
	{
		cout<<"enter the details"<<endl<<"*******************"<<endl;
		cout<<"�nter roll no of "<<i<<"student:  ";
		cin>>obj[i].rno;
		cout<<endl;
		cout<<"enter the name of "<<i<<"student:  ";
		cin>>obj[i].name;
		cout<<endl;
		cout<<"�nter marks of "<<i<<"student:    " ;
		cin>>obj[i].marks;

	}
	cout<<"data succesfully entered."<<endl;
cout<<endl<<endl<<endl;

cout<<"second students marks is:"<<obj[1].marks<<"\n name is:"<<obj[1].name;
return 0;
}
