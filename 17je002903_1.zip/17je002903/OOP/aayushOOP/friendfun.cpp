#include<bits/stdc++.h>
using namespace std;


class a{
	int no1=66;
	int no2=90;
	
	public:
		void fun(int a);
		
};
class b{
int no3;
int no4;
public:
	b()
	{
		no3=10;
		no4=20;
	}
friend void fun(int a)	;
		
};
class b::void fun(int p)
{
	cout<<"sum is :"<<p+no1+no2;
	
}



int main() {
b obj;
obj.fun(1);
	return 0;
}

