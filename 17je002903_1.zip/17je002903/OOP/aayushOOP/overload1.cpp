#include<bits/stdc++.h>
using namespace std;



class time
{
	int hours;
	int min;
	int sec;
public:
	time();
	void getdata();	
	void putdata()
	{
		cout<<"answer is "<<hours<<":"<<min<<":"<<sec;
	cin>>hours>>min>>sec;
	}
	
	
	
	time operator+(time);

	};
	
	time time::operator+(time t1){
	
	time t;
	int a,b;
	a=sec+t1.sec;
	t.sec=a%60;
	b=(a%60)+min+t1.min;
	t.min=b%60;
	t.hours=(b%60)+hours+t1.hours;
	t.hour=(hours%12);
	return t;
	}
void time::getdata()
{
	cout<<"enter hours:"<<endl;
	cin>>hours;
	cout<<"enter the minute:"<<endl;
	cin>>min;
	cout<<"enter the sec:"<<endl;
	cin>>sec;

	
}
int main()
 {
time p;time q;time r;
cout<"enter first time\n";
p.getdata();
cout<<"enter second time\n"<<endl;
q.getdata();
r=p+q;
cout<<"result is    :   "<<endl;
r.showdata();
return 0;
}





