#include<bits/stdc++.h>
using namespace std;
int flag=0;
int checkprime(int d);
int main() {
int num;
cout<<"finding prime numbers between 1 and entered number\n";
cout<<"enter the number :";
cin>>num;
cout<<endl;
int i;
for(i=3;i<=num;i++)
{
	if(checkprime(i)==1)
	{cout<<i<<endl;
	}
}
return 0;
}
int checkprime(int d)
{

	for(int a=2;a<=(d/2);a++)
	{
	if(d%a==0)
{flag=1;break;}}
return flag;
}












