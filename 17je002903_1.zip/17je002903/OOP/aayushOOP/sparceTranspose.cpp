#include<bits/stdc++.h>
using namespace std;

int main() {
	int m, n;
	cout<<"Enter the number of rows and columns\n";
	cin>>m>>n;
	int arr[m][n];
	
	for (int i=0; i<m; i++) {
		for (int j=0; j<n; j++){
			cout<<"Enter element arr["<<i<<"]["<<j<<']'<<'\n';
			cin>>arr[i][j];
		}
	}
	
	for(int j=0; j<n; j++) {
		for(int i=0; i<m; i++) {
			cout<<arr[i][j]<<endl;			
		}
	}
		
	

	return 0;
}

