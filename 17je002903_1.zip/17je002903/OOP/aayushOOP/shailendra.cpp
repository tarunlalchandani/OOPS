#include<bits/stdc++.h>
using namespace std;







int main() {
	
int a,intb,intc;
cout<<"�nter first number:"<<endl;
cin>>a;
cout<<�nter second	
	
	
	
	
	



return 0;
}

