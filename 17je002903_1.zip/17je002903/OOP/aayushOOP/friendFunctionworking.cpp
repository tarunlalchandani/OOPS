#include<bits/stdc++.h>
using namespace std;

void f(int a) {
	if(!a) a=10;
	return a;	
}





int main() {



	return 0;
}

