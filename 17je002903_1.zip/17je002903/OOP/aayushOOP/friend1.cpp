#include<bits/stdc++.h>
using namespace std;

class abc
{
	int a=1;
	int b=3;
	int c=5;
	public:
	friend int avg(abc d);
	};

int avg(abc d)
{
	int temp;
	temp=(d.a+d.b+d.c)/3;
	cout<<temp<<temp;;
	cout<<endl;

	return temp;
	
}


int main() {

abc j;
cout<<avg(j);



	return 0;
}

