#include<bits/stdc++.h>
using namespace std;

class student
{
	string name;
	int rno;
	int idno;
	public:
		student()
		{name=unknown;
		rno=0;idno=0;
		}
		string getname()
		{return name;}
		int getrollno()
		{return rno;}
		int getidno()
{	return idno;}
void getdata();

};



int main() {

student obj[8];
for(int i=1;i<=3;1++)
{
obj[i].getdata();	
}
for(i=1;i<=3;i++)
{
	obj[i].showdata();
}
return 0;
}
void student::getdata()
{
	cout<<"�nter the name"<<endl;
	cout<<"enter the roll number":"<<endl;
	cout<<"enter the id number:"<<endl;
	cin>>name>>rno>>idno;
}
void student::showdata()
{
	cout<<"name-"<<getname<<endl;
	cout<<"roll number-"<<rno<<endl;
	cout<<"id numbe-r"<<idno<<endl;
	
}






