#include<bits/stdc++.h>
using namespace std;
vector<int> binary(int n){
	vector<int> v;
	while(n!=1){
		int temp = n%2;
		n = n/2;
		v.push_back(temp);
	}
	v.push_back(n);
	reverse(v.begin(),v.end());
	return v;
}
int main() {
	
	int n;
	cout<<"Enter a decimal number";
	cin>>n;
	cout<<"the binary of the number is";
	vector<int> v1 = binary(n);
	for(int i=0;i<v1.size();i++){
		cout<<v1[i]<<" ";
	}
	
	
	

return 0;
}

