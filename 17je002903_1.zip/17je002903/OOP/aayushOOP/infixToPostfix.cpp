#include<bits/stdc++.h>
using namespace std;
//infix to postfix

int opVal(char c) {
	
	switch(c){
		case '+' : return 1;
		case '-' : return 1;
		case '*' : return 2;
		case '/' : return 2;
	}
	
}


bool isOperand(char c) {
	if((c >= 'a' && c <= 'z')||(c >= 'A' && c <= 'Z')){
			return true;
	}
	return false;
}


string infixToPostfix(string s) {
	string res = "";
	int n = s.length();
	
	stack <char> op;	
	
	for(int i=0; i<n; i++) {
		if(isOperand(s[i])) {
			res += s[i];
		}
		
		else {
			if(op.empty() || opVal(op.top()) <0 ) {
				//if stack is empty or operator is of greater priority;
				//push to stack
				op.push(s[i]);
			}
			
			
		}
	}
	
	
	
}






int main() {
//	cout<<infixToPostfix("a+b*c+d");
	cout<<opVal('*');
	return 0;
}

