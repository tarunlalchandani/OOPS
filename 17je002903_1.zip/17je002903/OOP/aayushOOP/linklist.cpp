
#include<bits/stdc++.h>
using namespace std;

struct node
{
int data;
node *next;
};

class linklist
 {
	public: 
	void insert();
	void display();
	void erase();
node *front=new node;
node *rear=new node;
linklist()
{
	front=NULL;
rear=NULL;
}


};
			
void linklist::insert()
{
			node *temp = new node;
			cout << "Enter value for the node:" << endl;
			cin >> temp->data;
			if(front == NULL) {
				temp->next = NULL;
				front = temp;
				rear = temp;
				cout << "Linked list Created!" << endl;
			}
			else {
				temp->next = NULL;
				rear->next = temp;
				rear = temp;
				cout << "Data Inserted in the Linked list!" << endl;
			}
		}
		
		void linklist:: display()
         {
			node *temp = new node;
			temp=front;
			cout << "List of data in Linked list" << endl;
			while(temp != NULL) {
				cout << temp->data << endl;
				temp =temp->next;
			}

 void linklist:: erase()
{
node *temp=new node;temp=front
while(temp!=rear)
{
	temp=temp->next;
}
temp=rear;
cout<<"deleted data is:"<<temp->data;
delete(temp);
}


int main() 
{

linklist l;
l.insert();
l.display();
return 0;
}

