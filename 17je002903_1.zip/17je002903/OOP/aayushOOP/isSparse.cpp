#include<bits/stdc++.h>
using namespace std;

int main() {
	int m, n;
	cout<<"Enter the number of rows and columns\n";
	cin>>m>>n;
	int arr[m][n];
	int totalZeros = 0;
	
	for (int i=0; i<m; i++) {
		for (int j=0; j<n; j++){
			cout<<"Enter element arr["<<i<<"]["<<j<<']'<<'\n';
			cin>>arr[i][j];
			if(arr[i][j] == 0) totalZeros++;
		}
	}
	
	if(2*totalZeros > m*n) cout<<"The given matrix is sparse.\n";
	else cout<<"The given matrix is not a sparse matrix\n";


	return 0;
}

