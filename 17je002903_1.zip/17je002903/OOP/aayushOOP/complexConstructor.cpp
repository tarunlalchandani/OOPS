#include<bits/stdc++.h>
using namespace std;

class Complex {
	float re;
	float im;
	
	
public:		
	Complex(float a, float b) {
		re = a;
		im = b;
	}
	
	Complex operator + (Complex c2) {
		Complex res(re + c2.re, im + c2.im);
		return res;
	}
	
	Complex operator - (Complex c2) {
		Complex res(re - c2.re, im - c2.im);
		return res;
	}
	
	Complex operator * (Complex c2) {
		Complex res(re*c2.re - im*c2.im, re*c2.im + im*c2.re);
		return res;
	}
	
	void printComplex() {
		cout<<re<<" + i("<<im<<")\n";
	}
	
};

int main() {
	Complex c1(1, 2), c2(2, 3);
	
	Complex c3 = c1+c2;
	Complex c4 = c1-c2;
	Complex c5 = c1*c2;
	
	
	c3.printComplex();
	c4.printComplex();
	c5.printComplex();
	


	return 0;
}

