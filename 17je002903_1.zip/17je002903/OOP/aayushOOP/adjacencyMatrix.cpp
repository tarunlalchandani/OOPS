#include<bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cout<<"Enter the number of nodes\n";
	cin>>n;
	bool isDirected;
	cout<<"Is it directed?\n";
	cin>>isDirected;
	
	int	arr[n][n];
	for(int i=0; i<n; i++) {
		for (int j=0; j<n; j++) {
			arr[i][j] = 0;
		}
	}
	
	int from, to;
	
	if(isDirected) {
		cout<<"-1 to quit\n";
		cout<<"\nEnter from: "; cin>>from;
		cout<<"\nEnter to: "; cin>>to;
		
		
		while(from!=-1 || to!=-1) {
			if(from>=n || to>=n) {
				cout<<"Invalid input";
				break;
			}
			
			arr[from][to] = 1;
			
			cout<<"\nEnter from: "; cin>>from;
			cout<<"\nEnter to: "; cin>>to;
		}
		
		
		for(int i=0; i<n; i++) {
			for (int j=0; j<n; j++) {
				cout<<arr[i][j]<<' ';
			}
			cout<<'\n';
		}
	}
	
	else {
		cout<<"-1 to quit\n";
		cout<<"\nEnter from: "; cin>>from;
		cout<<"\nEnter to: "; cin>>to;
		
		
		while(from!=-1 || to!=-1) {
			if(from>=n || to>=n) {
				cout<<"Invalid input";
				break;
			}
			
			arr[from][to] = 1;
			arr[to][from] = 1;
			
			cout<<"\nEnter from: "; cin>>from;
			cout<<"\nEnter to: "; cin>>to;
		}
		
		
		for(int i=0; i<n; i++) {
			for (int j=0; j<n; j++) {
				cout<<arr[i][j]<<' ';
			}
			cout<<'\n';
		}	
		
		
	}



	return 0;
}

