
#include<bits/stdc++.h>
using namespace std;

struct node
{
int data;
node *next;
};

class linkedlist {
	public: 
node *front=new node;
node *rear=new node;
linkedlist()
{
	front=NULL;
	rear=NULL;
}
	
		void insert() {
			node *temp = new node;
			cout << "Enter value for the node:" << endl;
			cin >> temp->data;
			if(front == NULL) {
				temp->next = NULL;
				front = temp;
				rear = temp;
				cout << "Linked list Created!" << endl;
			}
			else {
				temp->next = NULL;
				rear->next = temp;
				rear = temp;
				cout << "Data Inserted in the Linked list!" << endl;
			}
		}

		void display() {
			node *temp=new node;
			temp = front;
			cout << "List of data in Linked list" << endl;
			while(temp!= NULL) {
				cout << temp->data << endl;
				temp = temp->next;
			}
		}
	
	/*	
		void del() {
			
			int count = 0, number, i;
			for(node = first; node != NULL; node = node->next)
				count++;
			display();
			node *node1=new node;
			node1 = front;
			cout << count << " nodes available here!" << endl;
			cout << "Enter the node number which you want to delete:" << endl;
			cin >> number;
			if(number != 1) {
				if(number <= count) {
					for(i = 2; i <= number; i++)
						node = node->next;
					for(i = 2; i <= number-1; i++)
						node1 = node1->next;
					node1->next = node->next;
					node->next = NULL;
					node = NULL;
				}
				else
					cout << "Invalid node number!" << endl;
			}
			else {
				front = node->next;
				node = NULL;
			}
			cout << "Node has been deleted successfully!" << endl;
		}
	
};*/
int main()
{
	linkedlist l;
	l.insert();
	l.display();
	
}};
