#include<bits/stdc++.h>
using namespace std;

class Time {
	
	
public:
	int hh, mm, ss;
	
	
	Time (int h=0, int m=0, int s=0) {
		hh=h; ss=s; mm=m;
	}
	
	Time operator + (Time t1) {
		Time t3(0 , 0 , 0);
		//Second
		if(ss + t1.ss < 60) {
			t3.ss = ss + t1.ss;
		}
		else {
			t3.ss = ss + t1.ss - 60;
			t3.mm++;
		}
		
		//Minute
		if(mm + t1.mm + t3.mm <60) {
			t3.mm = mm + t1.mm + t3.mm;
		}
		
		else {
			t3.mm = mm + t1.mm + t3.mm - 60;
			t3.hh++;
		}
		
		
		//Hour		
		t3.hh = hh + t1.hh + t3.hh;
		
		
		
		return t3;
    }
    
    void getValue() {
    	cout<<"\nEnter hours:  "; cin>>hh;
    	cout<<"\nEnter minutes:  "; cin>>mm;
		cout<<"\nEnter seconds:  "; cin>>ss;
	}
    
    void print() {
    	cout<<'\n'<<hh<<':'<<mm<<':'<<ss<<'\n';
    }
		
};





int main() {
	
	Time t1, t2;
	
	t1.getValue();
	t2.getValue();
	
	Time t3 = t1+ t2;
	t3.print();


	return 0;
}

