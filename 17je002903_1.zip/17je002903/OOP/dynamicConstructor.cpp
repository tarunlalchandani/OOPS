#include<bits/stdc++.h>
using namespace std;

class Str{
	char* s;
	int len;
	
public:
		Str() {
			int l=0;
			s = new char[l+1];
		}
		
		Str(char* s2) {
			len = strlen(s2);
			
			s = new char[len+1];
			
			for(int i=0; i<len; i++) {
				s[i] = s2[i];
			}
			s[len] = '\0';
		}
		
		void add(char* s2) {
			int alen = strlen(s2);
			
			int newLen = alen + len;
			char* newSt = new char[newLen+1];
			char* oldS = s;
				
			for(int i=0; i<newLen; i++) {
				if(i<len) {
					newSt[i] = s[i];
				}
				else newSt[i] = s2[i-len];
			}
			
			s = newSt;
			len = newLen;
			s[len] = '\0';
			delete oldS;
			
		}
		
		void print() {
			cout<<s;
		}
};


int main() {
	Str s1("Hello");
	s1.print();
	cout<<endl;
	s1.add(" World!");
	s1.print();
	
	return 0;
}

