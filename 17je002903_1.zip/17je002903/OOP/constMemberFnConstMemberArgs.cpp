#include<bits/stdc++.h>
using namespace std;

class A {
	int data;
	
public:
	A() {
		data=0;	
	}
	
	A(int d) {
		data = d;
	}
	
	int getData() const {
		return data;
	}
};


int main() {
	A o1(5);
	cout<<o1.getData();


	return 0;
}

