#include<bits/stdc++.h>
using namespace std;

int main() {
	int sum, n;
	int arr[200];
	cout<<"\nEnter n: "; cin>>n;
	cout<<"\nEnter sum: "; cin>>sum;
	cout<<"\nEnter n elements of array:\n";
	for(int i=0; i<n; i++) cin>>arr[i];
	int B[200];
	


	return 0;
}

