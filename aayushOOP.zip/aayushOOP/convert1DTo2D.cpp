#include<bits/stdc++.h>
using namespace std;


int main() {
	int m;
	cout<<"Enter the number of elements\n";
	cin>>m;
	int arr[m];
	
	int twoD = sqrt(m)*sqrt(m) == m  ? sqrt(m) : sqrt(m) + 1; 
	int threeD = cbrt(m)*cbrt(m)*cbrt(m) == m  ? cbrt(m) : cbrt(m) + 1;
	
	cout<<twoD<<' '<<threeD;
	
	for (int i=0; i<m; i++) {
		cout<<"Enter arr["<<i<<"]\n";
		cin>>arr[i];
	}
	
	int tArr[twoD][twoD];
	for (int i=0; i<twoD; i++) {
		for(int j=0; j<twoD; j++) {
			if(i*j <= m) {
				tArr[i][j] = arr[m];
				m++;
			}
			else tArr[i][j] = 0;		
				
			cout<<tArr[i][j]<<endl;
		}		
	}	
	
	


	return 0;
}

