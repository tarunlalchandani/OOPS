#include<bits/stdc++.h>
using namespace std;







int main() {
	bool isPrime;
	
	for(int i=2; true; i++) {
		isPrime=true;
		for (int j=2; j*j<i+1; j++) {
			if(i%j == 0) {
				isPrime = false; break;
			}
		}
		
		if(isPrime) cout<<i<<'\t';
	}


	return 0;
}

