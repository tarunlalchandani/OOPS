#include<bits/stdc++.h>
using namespace std;



void swap(int a,int b);



int main() {
	int p,int q;
	cout<<�nter first number:"<<endl;
	cin>>p;
	cout<<�nter second number":<<endl;
	cin>>q;
	swap(p,q);
	



return 0;
}
void swap(int a,int b)
{
	
	a=a+b;
	b=a-b;
	a=a-b;
	cout<<"� value is"<<p<<endl;
	cout<<"b value is"<<q;
		
}
