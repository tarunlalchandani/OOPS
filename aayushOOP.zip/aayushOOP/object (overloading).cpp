#include<bits/stdc++.h>
using namespace std;


class D{

public:
	int a, b;
	
	void operator = (D ob) {
		a = ob.a;
		b = ob.b;
		
		return;
    }
	
	void getValue() {
		cout<<"\nEnter a: "; cin>>a;
		cout<<"\nEnter b: "; cin>>b;
	}
	
	void print() {
		cout<<"\na = "<<a<<"\nb = "<<b<<'\n';
	}
	
};




int main() {
	D ob1, ob2, ob3;
	
	ob1.getValue();
	ob2.getValue();
	
	ob1 = ob2;
	cout<<"\n\nObject 1 is:";
	ob1.print();
	
	
	

	return 0;
}

