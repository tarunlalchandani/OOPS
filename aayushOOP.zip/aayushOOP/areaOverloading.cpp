#include<bits/stdc++.h>
using namespace std;
//area overloading

class A{
	
public:
	float calc(float l) {
		return 3.14*l*l;
	}
	
	float calc(float l, float b) {
		return l*b;
	}
	
	float calc(float a, float b, float c) {
		float s = (a+b+c)/2;
		return sqrt(s*(s-a)*(s-b)*(s-c));
	}

	
};






int main() {
	A a;
	cout<<a.calc(2)<<'\n';
	cout<<a.calc(3, 4)<<'\n';
	cout<<a.calc(3, 4, 5)<<'\n';
	
	return 0;
}

