#include<bits/stdc++.h>
using namespace std;
void swapbyvalue(int a,int b);
void swapbyref(int &a,int &b);
void swapbyvalue(int p,int q)
{
	p=p+q;
	q=p-q;
	p=p-q;
	cout<<"�fter swapping:"<<endl<<"**********************"<<endl;
	cout<<"a="<<p<<"   "<<endl<<"b="<< q<<endl;

}

int main() {
int a;int b;
cout<<"�nter first no:"<<endl;
cin>>a;
cout<<"enter second number:"<<endl;
cin>>b;
swapbyvalue(a,b);
swapbyref(a,b);
return 0;
}

void swapbyref(int &p,int &q)
{
	
int temp;
temp=p;
p=q;
q=temp;	
cout<<"after swapping"<<endl<<"*******************"<<endl;
cout<<"a="<<p<<"    b="<<q;		
}













