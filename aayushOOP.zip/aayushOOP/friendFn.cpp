#include<bits/stdc++.h>
using namespace std;
 
class numbers
{
    int a, b, c;
public:
    numbers() {a = 0; b=0; c=0;}
    
    void getVal(){
    	cout<<"\nEnter a: ";cin>>a;
    	cout<<"\nEnter b: ";cin>>b;
    	cout<<"\nEnter c: ";cin>>c;
	}
	
	void printVal(){
		cout<<"\na = "<<a;
		cout<<"\nb = "<<b;
		cout<<"\nc = "<<c;
	}
    
    friend float calcAvg(numbers& num); // global friend function
};

float calcAvg(numbers& num) {
	float avg;
	
	avg = (num.a + num.b + num.c)/3.0 ;
	
	return avg;
	
}



int main()
{
    numbers o1, o2;
    o1.getVal();
    
    o1.printVal();
    
    cout<<"\nAverage is : "<<calcAvg(o1);
    return 0;
}



