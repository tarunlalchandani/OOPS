#include<bits/stdc++.h>
using namespace std;

class Prefix{
	int data;
	
	public:
		Prefix(int d){
			data = d;
		}
		
		void operator ++(){
			data+=2;
		}
		
		void operator ++(int p){
			data+=3;
		}
		
		void printData(){
			cout<<data<<'\n';
		}
	
		
};




int main() {
	Prefix a(5);
	++a;
	a.printData();
	a++;
	a.printData();


	return 0;
}



