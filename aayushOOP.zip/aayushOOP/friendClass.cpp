#include<bits/stdc++.h>
using namespace std;

class A{
	
	
};


class B{
	
	
};




int main() {



	return 0;
}

