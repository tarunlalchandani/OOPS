#include<bits/stdc++.h>
using namespace std;
int main(){
	int ninp,noutp,ninq,file,ext,effort,td,ud,cost;
	cin>>ninp>>noutp>>ninq>>file>>ext>>effort>>td>>ud>>cost;
	int fpoint=ninp*4+noutp*5+ninq*4+file*10+ext*10;
	cout<<"Function Point "<<fpoint<<endl;
	return 0;
}
