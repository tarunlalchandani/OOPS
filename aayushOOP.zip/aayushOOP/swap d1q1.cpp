//swap variabls using function
#include<bits/stdc++.h>
using namespace std;

void swapAddr(int *a, int *b){
	int temp = *a;
	*a = *b;
	*b = temp;	
}

void swapRef(int &a, int &b){
	int temp = a;
	a = b;
	b = temp;	
	
}


int main() {
	int a, b;
	cout<<"Enter a and b: \n";
	cin>>a>>b;
	
	swapAddr(&a, &b);
	cout<<"\nAfter swapping by address\na= "<<a<<"b= "<<b;
	swapRef(a, b);
	cout<<"\nAfter swapping by reference\na= "<<a<<"b= "<<b;
	
}
