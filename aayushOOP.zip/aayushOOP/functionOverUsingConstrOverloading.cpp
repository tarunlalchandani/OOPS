#include<bits/stdc++.h>
using namespace std;
//function overloading using constructor overloading

class St {

public:
	St(string s) {
		int i=0, j=s.length();
		
		bool isPalin = true;
		
		for(i, j; i<=j; i++, j-- ) {
			if(s[i] != s[j]) {
				isPalin = false;
				break;
			}
		}
		
		if(isPalin) cout<<"It is a palindrome\n";
		else cout<<"Not a palindrome\n";
		
	}
	
	St (string s1, string s2) {
		if(s2.compare(s1) == 0)	cout<<"Equal\n";
		else cout<<"Not Equal\n";
	}
	
	St (string s1, string s2, string s3) {
		cout<<s1+s2+s3;
	}
};






int main() {
	St("abc");
	St("abc", "abc");	
	St("abc", "cde", "dce");
	
	
	return 0;
}

