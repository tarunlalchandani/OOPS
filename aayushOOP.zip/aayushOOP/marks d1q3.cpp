#include<bits/stdc++.h>
using namespace std;

class sub {
	string name;
	float marks;
public:
	void setName(string n){
		name = n;
	}
	
	void setMarks(float m) {
		marks = m;
	}
	float getMarks() {
		return marks;
	}
	
};


class student {
	sub subject[4];
	
public:
	void setMarks(){		
		for(int i=0; i<4; i++) {
			cout<<"Subject "<<i+1<<" Name, Marks\n";
			float currMarks; string currName;
			cin>>currName>>currMarks;
			subject[i].setName(currName);
			subject[i].setMarks(currMarks);
		}
	}
	
	float calcAvg();
	float calcTotal();
	float calcGPA();
};

float student::calcTotal() {
	int total = 0;
	for(int i=0; i<4; i++)
	{
		total+=subject[i].getMarks();
	}
	return total;
}


float student::calcAvg() {
	return calcTotal()/4;
}

float student::calcGPA() {
	return calcAvg()/9.5;
}

int main() {
	int num;
	cout<<"Enter the number of students\n";
	cin>>num;
	student s[num];
	
	for(int i=0; i<num; i++) {
		cout<<"Student #"<<i+1<<" : \n";
		s[i].setMarks();
	}
	
	cout<<endl<<s[0].calcTotal();
	cout<<endl<<s[0].calcAvg();
	cout<<endl<<s[0].calcGPA();
	
	
	
	
	
}
