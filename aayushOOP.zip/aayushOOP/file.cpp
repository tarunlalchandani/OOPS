#include<bits/stdc++.h>
using namespace std;







int main() {


int a;int num;
ifstream fin1,fin2;
ofstream fout1,fout2;
fout1.open("�dd.txt");
fin1.open("odd.txt");
fin2.open("�ven.txt");
fout2.open("even.txt");
/*cout<<"how much number do you wan enter:";
cin>>a;
cout<<endl;
for(int i=1;i<=a;i++)
{cin>>num;
if(num%2==0)
{fout2<<num;}
else{fout1<<num;}
}*/
fout1<<"this is the content of the file";
while(!fin1.eof())
{string s1;
	fin1>>s1;
	cout<<s1<<endl;
}
fin1.close();
fin2.close();fout2.close();
fout2.close();
return 0;
}

